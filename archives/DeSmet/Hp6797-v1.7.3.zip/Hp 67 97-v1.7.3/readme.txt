Howto:

When installing a new release clean the registry : HKCU/Software/
remove HP67, HP97, HP97p

Then launch the program, use 'kml' to choose a config, and then save
a document to re-create the registry. The next launch will be a direct reload.

New
1.7.3
STO (e) was buggy, corrected

1.7.2
Bug on rom load corrected

1.7.1
Update speed refs ... now max speed is more speedy :)
Some bugs in patched rom
norm2hd.py to convert normal pack to hd pack

1.7
new HP97 model : HP97+ fully loaded HP97

896 program steps

106 registers (A to I are regs 100 to 105)

HD magnetic cards : one side is enough for either:
- whole program memory 
- whole register set
Be careful not to mix your cards sets
(a tool to convert cards set will be done soon)

5 new instructions: one more indirect register E
RCL (e) keyed as 'RCL' 'e^x', printed as 'RCLe'
STO (e) keyed as 'STO' 'e^x', printed as 'STOe'
GTO (e) keyed as 'GTO' 'e^x', printed as 'GT->e'
GSB (e) keyed as 'GSB' 'e^x', printed as 'GS->e'
use the E register as a new indirect one, same functionnalities as I register
BACK x keyed as 'LBL' 'e^x', printed as 'Bc^x'
go back 'stack X' steps (stack X doesn't need to be negative)

97.src.lst is a commented source of the HP97 rom's
can be assembled with 'ass97.py' to produce 
- original roms (define HP97+ as 0)
- patched roms (define HP97+ as 1)

new display font (more realistic I hope)

1.6
rather correct text output of printer in prt97-xxx.txt in unicode 16 (use courier new font)
can choose if automatic display of inserted card or not
take care of idle and pause delay at speed greater than 1
registry settings to deal with current card pack

delete all previous save of .e67 and e97 files

v1.5
bug at reload of document corrected

v1.4
Activated registry save (settings and last document auto open)
If you have problem to launch, try to clean the registry base :
remove HKEY_CURRENT_USER\Software\HP97 whole entry and
HKEY_CURRENT_USER\Software\HP67

v1.3
Added mini print display

v1.2
Choose a font :)

v1.1
R/S bug corrected on HP67
max speed added

added an autochecksum option to make special cards by 'hands'
the checksum is computed at read time so write again to save it on the card
(and don't forget to save the pack either on disk)

HP 97 emulator v0.1 (c) 2011 O. De Smet

- full featured emulator
- printer working
- card reader ok (MERGE still not working, otherwise ok)
- card pack concept (standard pack is given, try right-clicks)

scancode shorcuts are for a french keymap, feel free to modify it

Rom taken from an old release of non-pareil
Some hints taken from the non pareil sources
More hints taken from schematics from HP97 service manual
More hints from a personnal dis-assembly of the roms (see 97.obj.lst)

HP 67 emulator v0.1 (c) 2011 O. De Smet

- same base, keyboard shortcuts differents

To insert side 1 of a card, right click on the left part of the card (side 1)
for side 2, right click on the right part of the card (side 2) to make the pop-up menu appear

To remove card from the display, click on the card slot ON hp97 picture, click on the right part of the 
card ON the hp67 picture

The printer adv button is active and also mapped on ' ' key for the hp97

The on/off slide reset the calculator

Printer mode slide is active for the hp97

Prgm/run slide is active but only animated on hp97

After writing a card with the emulator you NEED to save the pack on disk, it's not automatic

You can fiddle with the .pck files with a text editor, and use the 'auto checksum' to read 
such hacked card :)
Write the card afterwards to have the checksum on the card and save the pack to have it on the file.

Kind '2' card are 'pack' cards with protection
To edit change kind as 1, remove protection and after 'write' change back to kind 2
then save again the pack on the file ...

 