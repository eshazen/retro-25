#
# convert normal density pack to hd pack
# simply put 2 side of a normal card as 1 side of a HD card
#
# no tests for data vs prgm
# will scratch data cards, but who cares ;)
#

import string

def send(i, n = 1, line_spe='none'):
    if (line_spe == 'none'):
        for j in range(n):
            f.write(line[i])
            i += 1
        return i
    else:
        for j in range(n):
            f.write(line_spe)
            i += 1
        return i
        
f_in = 'Math 1.pck'
f_out = 'Math 1 HD.pck'

f = open(f_in, 'rt')
line = f.readlines(-1)
f.close()

f = open(f_out, 'wt')
# header
line[0] = line[0][:-1] + ' HD\n'
i = send(0, 3)
n_card = int(line[i-1], 0)

for card in range(n_card):
    # header
    i = send(i, 14)
    line[i] = line[i][0:3]+'+\n'
    i = send(i, 1)
    checksum = 0
    # prgm header
    i = send(i, 1)
    checksum = int('0x'+line[i-1],0)
    # side 1 (steps 1-112) 32 records
    for k in range(32):
        checksum += int('0x'+line[i][0:7],0)
        i = send(i, 1)
    # skip side 1 checksum
    i += 1
    # skip side 2 decl
    i += 1
    # skip side 2 header
    i += 1
    # side 2 (steps 113-224)
    for k in range(32):
        checksum += int('0x'+line[i][0:7],0)
        # print checksum
        i = send(i, 1)
    # skip side checksum
    i += 1
    # pad empty records
    send(i, 256-64, '0000000\n')
    # send checksum
    hck = '%010X' % checksum
    # hck = hex(checksum)[3:]
    # hck = '000000'+hck
    if (hck[-1] == 'L'):
        hck = hck[:-1]
    send(i, 1, hck[-7:]+'\n')
    # empty side 2
    send(i, 1, 'S2 +\n')
    send(i, 258, '0000000\n')

    print 'card', card, 'done'
send(i, 1)
f.close()
print 'pack done'


